// Global variables
let map;
let busMarkers = {};
let stopMarkers = {};
let selectedLine = '';
let selectedBus = null;
let selectedStop = null;
let busesData = [];
let stopsData = [];
let errorModal;
let updateTimer;
const refreshInterval = 15000; // 15 seconds
let userPosition = null;
let nearbyRadius = 500; // Default radius for nearby stops (meters)

// Bus icon colors by line (will be assigned dynamically)
const lineColors = {};
let colorIndex = 0;
const colors = [
    '#FF5733', '#33FF57', '#3357FF', '#F033FF', '#FF33A8', 
    '#33FFF0', '#FFD700', '#FF6B6B', '#6BFF6B', '#6B6BFF'
];

// Layer groups
let busLayer;
let stopLayer;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initMap();
    initUI();
    loadBusLines();
    fetchBusData();
    
    // Set up auto-refresh
    updateTimer = setInterval(fetchBusData, refreshInterval);
});

// Initialize the map
function initMap() {
    // Montevideo coordinates
    const mvdCenter = [-34.9011, -56.1645];
    
    // Create map
    map = L.map('map').setView(mvdCenter, 13);
    
    // Add OpenStreetMap tiles to show streets clearly
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);
    
    // Create layer groups
    busLayer = L.layerGroup().addTo(map);
    stopLayer = L.layerGroup().addTo(map);
    
    // Add layer control
    const overlays = {
        "Buses": busLayer,
        "Paradas": stopLayer
    };
    
    L.control.layers(null, overlays, {
        position: 'topright',
        collapsed: false
    }).addTo(map);
    
    // Add geolocation control
    const locateControl = L.control.locate({
        position: 'topright',
        locateOptions: {
            enableHighAccuracy: true,
            watch: true      // Watch user's location (continuously update)
        },
        strings: {
            title: "Mi ubicación",
            popup: "Estás aquí"
        },
        flyTo: true,
        showPopup: true,
        icon: 'fa fa-location-arrow'
    }).addTo(map);
    
    // Add scale control
    L.control.scale({
        imperial: false,     // Only show metric scale
        position: 'bottomleft'
    }).addTo(map);
    
    // Force map to recalculate its size
    setTimeout(() => {
        map.invalidateSize();
    }, 100);
    
    // When map is moved or zoomed, update nearby stops if user position is available
    map.on('moveend', function() {
        if (userPosition) {
            fetchNearbyStops(userPosition.lat, userPosition.lng);
        }
    });
    
    // When user location is found
    map.on('locationfound', function(e) {
        console.log("Location found:", e.latlng);
        userPosition = e.latlng;
        
        // Fetch nearby stops
        fetchNearbyStops(userPosition.lat, userPosition.lng);
        
        // Hide simulation badge if we are using real data
        const simulationBadge = document.getElementById('simulation-badge');
        if (simulationBadge) {
            simulationBadge.style.display = 'none';
        }
    });
    
    // Handle map click events - for debugging coordinates
    map.on('click', function(e) {
        console.log("Map clicked at: " + e.latlng.lat + ", " + e.latlng.lng);
    });
}

// Initialize UI elements
function initUI() {
    // Initialize error modal
    errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
    
    // Show simulation mode badge if in simulation mode
    const simulationBadge = document.getElementById('simulation-badge');
    if (simulationBadge) {
        // Will be hidden if we later connect to the real API
        simulationBadge.style.display = 'inline-block';
    }
    
    // Line filter change event
    document.getElementById('lineFilter').addEventListener('change', function() {
        selectedLine = this.value;
        fetchBusData(selectedLine);
    });
    
    // Refresh button click event
    document.getElementById('refreshButton').addEventListener('click', function() {
        this.classList.add('fa-spin');
        fetchBusData();
        setTimeout(() => {
            this.classList.remove('fa-spin');
        }, 1000);
    });
    
    // Retry button click event
    document.getElementById('retryButton').addEventListener('click', function() {
        errorModal.hide();
        fetchBusData();
    });
}

// Load bus lines for the filter dropdown
function loadBusLines() {
    updateStatus('Loading bus lines...');
    
    fetch('/api/lines')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(lines => {
            const lineFilter = document.getElementById('lineFilter');
            
            // Clear existing options except "All Lines"
            while (lineFilter.options.length > 1) {
                lineFilter.remove(1);
            }
            
            // Add lines to dropdown
            lines.forEach(line => {
                const option = document.createElement('option');
                option.value = line;
                option.textContent = line;
                lineFilter.appendChild(option);
                
                // Assign a color to this line
                if (!lineColors[line]) {
                    lineColors[line] = colors[colorIndex % colors.length];
                    colorIndex++;
                }
            });
            
            updateStatus('Bus lines loaded.');
        })
        .catch(error => {
            console.error('Error loading bus lines:', error);
            showError('Failed to load bus lines', error.message);
        });
}

// Fetch bus data from API
function fetchBusData(line) {
    updateStatus('Updating bus positions...');
    
    // Build the URL with optional line parameter
    const url = line ? `/api/buses?line=${line}` : '/api/buses';
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            busesData = data;
            updateMap();
            updateStatus(`Showing ${busesData.length} buses. Last update: ${new Date().toLocaleTimeString()}`);
        })
        .catch(error => {
            console.error('Error fetching bus data:', error);
            showError('Failed to load bus data', error.message);
            updateStatus('Error loading data. Click refresh to try again.', 'danger');
        });
}

// Update the map with bus positions
function updateMap() {
    // Filter buses if a line is selected
    const filteredBuses = selectedLine 
        ? busesData.filter(bus => bus.line === selectedLine)
        : busesData;
    
    // Keep track of markers to remove
    const markersToKeep = {};
    
    // Update or create markers for each bus
    filteredBuses.forEach(bus => {
        // Check if we have valid coordinates
        if (!bus.latitude || !bus.longitude) return;
        
        const busId = bus.id || `${bus.line}-${bus.order}`;
        markersToKeep[busId] = true;
        
        // Get or create bus marker
        if (busMarkers[busId]) {
            // Update existing marker
            busMarkers[busId].setLatLng([bus.latitude, bus.longitude]);
            if (bus.heading !== undefined) {
                busMarkers[busId].setRotationAngle(bus.heading);
            }
            
            // Update popup content if this is the selected bus
            if (selectedBus === busId) {
                updateBusInfo(bus);
            }
        } else {
            // Create new marker
            createBusMarker(bus, busId);
        }
    });
    
    // Remove markers for buses no longer in the data
    Object.keys(busMarkers).forEach(id => {
        if (!markersToKeep[id]) {
            map.removeLayer(busMarkers[id]);
            delete busMarkers[id];
            
            // If this was the selected bus, clear the info panel
            if (selectedBus === id) {
                clearBusInfo();
            }
        }
    });
    
    // Update the count in the status bar
    updateStatus(`Showing ${filteredBuses.length} buses. Last update: ${new Date().toLocaleTimeString()}`);
}

// Create a new bus marker
function createBusMarker(bus, busId) {
    const busLine = bus.line || 'Unknown';
    
    // Create custom bus icon
    const busIcon = L.icon({
        iconUrl: '/static/img/bus-icon.svg',
        iconSize: [32, 32],
        iconAnchor: [16, 16],
        popupAnchor: [0, -16],
        className: `bus-line-${busLine}` // For potential CSS styling
    });
    
    // Create marker with rotation
    const marker = L.marker([bus.latitude, bus.longitude], {
        icon: busIcon,
        rotationAngle: bus.heading || 0,
        rotationOrigin: 'center center'
    }).addTo(busLayer);  // Add to bus layer instead of directly to map
    
    // Add click handler
    marker.on('click', function() {
        selectedBus = busId;
        updateBusInfo(bus);
    });
    
    // Create tooltip with bus info
    marker.bindTooltip(`Línea ${busLine} → ${bus.destination || 'Unknown'}`, { 
        direction: 'top',
        offset: [0, -15]
    });
    
    // Store the marker
    busMarkers[busId] = marker;
}

// Fetch nearby bus stops
function fetchNearbyStops(lat, lng) {
    updateStatus('Buscando paradas cercanas...');
    
    // Build the URL with location parameters
    const url = `/api/stops?lat=${lat}&lng=${lng}&radius=${nearbyRadius}`;
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            stopsData = data;
            updateStopMarkers();
            updateStatus(`Showing ${busesData.length} buses and ${stopsData.length} stops.`);
        })
        .catch(error => {
            console.error('Error fetching stop data:', error);
            showError('Failed to load bus stops', error.message);
        });
}

// Update the stop markers on the map
function updateStopMarkers() {
    // Clear all existing stop markers
    stopLayer.clearLayers();
    stopMarkers = {};
    
    // Create markers for each stop
    stopsData.forEach(stop => {
        // Check if we have valid coordinates
        if (!stop.latitude || !stop.longitude) return;
        
        createStopMarker(stop);
    });
    
    console.log(`Added ${stopsData.length} stop markers to map`);
}

// Create a new stop marker
function createStopMarker(stop) {
    // Create stop icon using SVG
    const stopIcon = L.icon({
        iconUrl: '/static/img/stop-icon.svg',
        iconSize: [24, 24],
        iconAnchor: [12, 24],
        popupAnchor: [0, -24]
    });
    
    // Create marker
    const marker = L.marker([stop.latitude, stop.longitude], {
        icon: stopIcon
    }).addTo(stopLayer);
    
    // Create popup with stop info
    let busLinesList = '';
    if (stop.lines && stop.lines.length > 0) {
        busLinesList = `<p>Líneas: ${stop.lines.join(', ')}</p>`;
    }
    
    const popupContent = `
        <div class="stop-popup">
            <h5>${stop.name || 'Parada'}</h5>
            <p>${stop.code || ''}</p>
            <p>${stop.address || ''}</p>
            ${busLinesList}
        </div>
    `;
    
    marker.bindPopup(popupContent);
    
    // Create tooltip with basic info
    marker.bindTooltip(stop.name || 'Parada de bus', { 
        direction: 'top',
        offset: [0, -10]
    });
    
    // Store the marker
    stopMarkers[stop.id] = marker;
}

// Update the bus information panel
function updateBusInfo(bus) {
    const busDetails = document.getElementById('busDetails');
    busDetails.classList.remove('d-none');
    
    document.getElementById('busLine').textContent = bus.line || 'Unknown';
    document.getElementById('busDirection').textContent = bus.destination || 'Unknown';
    document.getElementById('busSpeed').textContent = (bus.speed !== undefined) 
        ? `${bus.speed} km/h` 
        : 'Unknown';
    
    const timestamp = bus.timestamp 
        ? new Date(bus.timestamp).toLocaleTimeString() 
        : 'Unknown';
    document.getElementById('busUpdate').textContent = timestamp;
}

// Clear the bus information panel
function clearBusInfo() {
    document.getElementById('busDetails').classList.add('d-none');
    selectedBus = null;
}

// Update the status bar
function updateStatus(message, type = 'info') {
    const statusBar = document.getElementById('statusBar');
    statusBar.textContent = message;
    
    // Update status type (color)
    statusBar.className = `alert alert-${type} m-0 rounded-0 text-center`;
}

// Show error modal
function showError(title, message) {
    document.getElementById('errorModalLabel').textContent = title;
    document.getElementById('errorModalBody').textContent = message;
    errorModal.show();
}
